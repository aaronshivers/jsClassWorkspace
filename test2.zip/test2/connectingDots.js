const string = 'Hello There'

const upped = string.toUpperCase()

const lowered = string.toLowerCase()

const length = string.length

console.log(upped)
console.log(lowered)
console.log(length)
