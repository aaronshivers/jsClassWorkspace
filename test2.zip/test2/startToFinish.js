const numbers = [1, 2, 3, 4]

const vowels = ['a', 'e', 'i', 'o', 'u']

const people = [{
  name: 'Bob'
}, {
  name: 'Sally'
}, {
  name: 'Mary'
}]