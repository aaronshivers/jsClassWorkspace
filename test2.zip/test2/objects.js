const person = {
  name: 'Chester',
  age: 72,
  state: 'Kansas'
}

const dog = {
  name: 'Sparky',
  color: 'white',
  neutered: false
}

const sandwich = {
  bread: 'wheat',
  meat: 'turkey',
  isTasty: true
}
