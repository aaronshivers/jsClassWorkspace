// add two numbers
const add = (x, y) => x + y

// subtract two numbers
const subtract = (x, y) => x - y

// multiply two numbers
const multiply = (x, y) => x * y

// divide two numbers
const divide = (x, y) => x / y

// log result of add()
console.log(add(3, 7))

// log result of subtract()
console.log(subtract(3, 7))

// log result of multiply()
console.log(multiply(3, 7))

// log result of divide()
console.log(divide(3, 7))
