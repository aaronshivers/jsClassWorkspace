const withoutEnd = string => string.substring(1, string.length - 1)

console.log(withoutEnd("Hello")) // "ell"
console.log(withoutEnd("java")) // "av"
console.log(withoutEnd("coding")) // "odin
